rm(list=ls())

library(MASS)
library(mvtnorm)
library(expm) 
library(stringr)
library(abind)
library(Directional)
library(Matrix)

source("sourceAll.R")
path = paste(getwd(), "/functions", sep="")
sourceDir(path)

##############################

# MCMC sample size
n.burn = n.reps = 1000

# number of artificial datasets
indep.reps = 50

# small.X = TRUE --> analyze using Skinny Bayesian method
small.X = TRUE

# Relevant only if small.X--
# Input parameter r_0^2 in equation (10) of Guha and Datta (202)
r0sq=.99

# number of OTUs
p = 150
# number of observations
n = 45

# tau_0 of Simulation Study
input.tau = 5
 
estTau.v = corD.v = corV.v = corX.v = corB.v = q.v = array(,indep.reps)
tauCheck.v = DCheck.v = VCheck.v = array(,indep.reps)
tauCI.mt = array(,c(indep.reps,2))
  
#############################################


  for (loop in 1:indep.reps)
        {

    
        set.seed(loop)
      
        # generate data
        sim.X <- gen.Data(n, p, small.X, r0sq, input.tau)
        data = sim.X$data
        true_parm = sim.X$true_parm
        rm(sim.X)
  
        # analyze data
        All.Stuff <- fn.mcmc(data, n.burn, n.reps, TauRSq=.95)
      
        est = fn.trueAnalysis(All.Stuff, true_parm)
      
        q.v[loop] = data$q
        
        estTau.v[loop] = est$tau
        corD.v[loop] = est$corD
        corV.v[loop] = est$corV
        corX.v[loop] = est$corX
        corB.v[loop] = est$corB
      
        tauCI.mt[loop,] = est$tauCI
        
        print("********************************************")
        print(paste("****** FINISHED SET ", loop, ", n=",n,", p=",p,"***********", sep=""))
        print("********************************************")
      
        save(list = ls(all.names = TRUE), file = ".RData", envir = .GlobalEnv)
        }
  
