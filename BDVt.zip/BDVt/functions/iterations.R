

fn.dmvnorm <- function(x, mean, sigma, inv.sigma, log=TRUE)
	{

	if (missing(inv.sigma))
		{inv.sigma <- solve(sigma)
		}

	logdet <- as.numeric(determinant(inv.sigma, logarithm=TRUE)$mod)
	r <- length(x)
	Q <- colSums(inv.sigma * (x-mean))
	Q <- sum(Q * (x-mean))

	val <- -r/2*log(2*pi) + logdet/2 - Q/2
	if (!log)
		{val <- exp(val)
		}

	val
	}

fn.vvT = function(v)
{ v = matrix(v, ncol=1)
  
  if (length(v)>1)
    {const =  v %*% t(v)
    }
  if (length(v)==1)
  {const =  v^2
  }
  const
}


fn.trace <- function(M)
{sum(diag(M))}


fn.nullColSpace <- function(M)
{
  moreCols = nrow(M) - rankMatrix(M)
  
  flag = moreCols == 0
  
  if (flag)
    {N0 = matrix(rep(0,nrow(M)), nrow=nrow(M))
    }
  
  if (!flag)
    {noise.mt = matrix(runif(n=nrow(M)*moreCols), nrow=nrow(M))
    MPlus = cbind(M, noise.mt)
    MPlus.qr = qr(MPlus)
    UPlus =qr.Q(MPlus.qr)
    N0 = matrix(UPlus[,-(1:rankMatrix(M))], nrow=nrow(M))
    }
  
   errFlag = sum(abs(t(N0) %*% M) > 1e-10) > 0
  if (errFlag)
  {stop("N0 column space not orthogonal to M")}
  
  N0
  
}


fn.SmallX <- function(data, r0sq=.99, small.X)
{
  data$fullX = data$X
 
  data$include.x = 1:data$p
  
  if (small.X)
  {
  tmp = colSums(data$fullX^2)
  data$reverseRank.v = reverseRank.v = ncol(data$fullX) - rank(tmp, ties.method = "first") + 1
  
  tmp2 = sort(tmp, decreasing = TRUE)
  tmp3 = cumsum(tmp2)/sum(data$fullX^2)
  howMany = max(which(tmp3 <= r0sq)) + 1
  data$include.x = which(data$reverseRank.v <= howMany)
  
  data$X = data$fullX[,data$include.x]
  data$p = ncol(data$X)
  
  } 
  
  data$X2 = data$fullX[,-data$include.x]
  data$p2 = ncol(data$X2)
  
  data
}

fn.dataSummary <- function(data, small.X)
{
  data$Q = t(data$X) %*% data$B
  
  data$B0 = fn.nullColSpace(data$B)
  
  data$QtQ = t(data$Q) %*% data$Q
  
  data$traceQtQ = fn.trace(data$QtQ)
  tmpMat = t(data$B0) %*% data$X
  
  data$fBX = sum(tmpMat^2) + data$traceQtQ
  
  data$frobX2 = 0
    
  if (small.X)
    {data$frobX2 = sum(data$X2^2)
    }
  
  data
}


fn.frobStar <- function(data, parm)
{
  parm$R = t(data$Q) %*% parm$V
  
  parm$frobStar = sum(parm$D.v^2) - 2*fn.trace(t(parm$R * parm$D.v))
  
  parm$frob = parm$frobStar + data$fBX
  
 
  parm 
}


fn.init <- function(data, TauRSq)
	{

	parm <- NULL

	parm$n <- data$n
	parm$p <- data$p

	Q.qr = qr(data$Q)
	parm$V =qr.Q(Q.qr)
	parm$D.v = sqrt(colSums(data$Q^2))
	
	Q.hat =  t(t(parm$V) * parm$D.v)
	
	parm$tau = 1/sqrt((1-TauRSq)*var(as.vector(data$X))) #1/sd(as.vector(data$Q - Q.hat))
	
	parm = fn.frobStar(data, parm)
	
	parm$varX = var(as.vector(data$X))
	parm$X2 = sum(data$X^2)
	
	parm

	}



fn.gen.D <- function(data, parm)
{
  parm = fn.frobStar(data, parm)
  
  r.v = diag(parm$R)
  u.min.v = pnorm(0,r.v, 1/parm$tau)
  
  for (j in 1:data$q)
  {
    u.min <- u.min.v[j]
    flag = u.min > 1-1e-4
    
    if (flag)
      {parm$D.v[j] = 0
      }
    
    if (!flag)
      {gen.u <- runif(n=1, min=u.min)
      parm$D.v[j] = qnorm(gen.u, r.v[j], 1/parm$tau)
      }
  }
  
  parm = fn.frobStar(data, parm)
  
  parm
}


fn.gen.tau  <- function(data, parm)
	{
  parm = fn.frobStar(data, parm) 

  parm$tau <- sqrt(rgamma(n=1,shape=(data$n*data$p/2+1), rate=parm$frob/2))
  
	parm
	}



fn.MFvM <- function(V,C)
  {
  
  tmp = svd(C)
  U = tmp$u
  W = tmp$v
  D.v = tmp$d
  
  H = t(t(U) * D.v)
  
  Y = V %*% W
  
  r = ncol(Y)
  
  for (t in 1:r)
  {
    Y.minus.t = Y[,-t]
    N = fn.nullColSpace(Y.minus.t)
    h.t = as.vector(t(N) %*% H[,t])
    k = sqrt(sum(h.t^2))
    z = 1
    if (ncol(N)>1)
      {z = as.vector(rvmf(n=1,mu=h.t/k,k))
      }
    Y[,t] = as.vector(N %*% z)
  }
  
  V = Y %*% t(W)
  
  return(V)
  }

fn.gen.V  <- function(data, parm)
{
  parm$C = parm$tau^2 * t(t(data$Q) * parm$D.v)

  parm$V = fn.MFvM(V=parm$V,C=parm$C)
  
  parm
}


fn.analyzeXB <- function(parm)
{
  tmp = t(parm$V) * parm$D.v
  parm$X.hat = data$B %*% tmp
  
  parm$OTU_contrib.v = colSums(tmp^2)/sum(parm$X.hat^2)*100
  
  parm$B.hat = t(t(data$X %*% parm$V)/parm$D.v)
  
  parm$percentVarX = array(,3)
  
  parm$Xhat2 = sum(parm$X.hat^2)
  parm$res2 = sum((parm$X.hat-data$X)^2)
  parm$percentVarX[1] = 1-(1/parm$tau^2)/parm$varX
  parm$percentVarX[2] = parm$Xhat2/parm$X2
  parm$percentVarX[3] = 1-parm$res2/parm$X2
  
  parm$r2 <- rep(0, data$q)
  for (k in 1:data$q) parm$r2[k] <- sum(data$B[, k] * parm$B.hat[, k])/sum(parm$B.hat[, k]^2)
  
  parm
}


fn.iter <- function(data, parm)
	{
  parm = fn.gen.D(data, parm)
  
  parm = fn.gen.tau(data, parm)
  
  parm = fn.gen.V(data, parm)
  
  parm=	fn.analyzeXB(parm)

  parm
	}


fn.mcmc <- function(data, n.burn, n.reps, TauRSq=.95)
	{

	parm <- fn.init(data, TauRSq)
	init.parm <- parm

	for (cc in 1:n.burn)
		{parm <- fn.iter(data, parm)
		
		if (cc %% 10 == 0)
			{print(paste("BURN = ",cc,date(),"***********"))
			}
		}


	All.Stuff <- NULL
	#
	All.Stuff$tau.v <- array(,n.reps)
	All.Stuff$V.mt  <- All.Stuff$VSq.mt  <- array(0,dim(parm$V))
	All.Stuff$D.mt  <- array(0,c(length(parm$D.v),n.reps))
	
	All.Stuff$XPercentVar.mt <- array(,c(3,n.reps))
	
	All.Stuff$BRSq.mt <- array(,c(data$q,n.reps))
	
	All.Stuff$OTU_contrib.mt <- array(,c(data$p,n.reps))
	
	##########################################
	## POST-BURNIN
	##########################################

	for (cc in 1:n.reps)
	{parm <- fn.iter(data, parm)
	
	All.Stuff$tau.v[cc] <- parm$tau
	All.Stuff$V.mt  <- All.Stuff$V.mt + parm$V
	All.Stuff$VSq.mt  <- All.Stuff$VSq.mt + parm$V^2
	All.Stuff$D.mt[,cc]  <- parm$D.v
	
	All.Stuff$BRSq.mt[,cc] <- parm$r2
	
	All.Stuff$OTU_contrib.mt[,cc] <- parm$OTU_contrib.v
	 
	All.Stuff$XPercentVar.mt[,cc] <- parm$percentVarX
	

	if (cc %% 10 == 0)
	  {print(paste("REPS = ",cc,date(),"***********"))
	  }
	}
	
	All.Stuff$V.mt <- All.Stuff$V.mt/n.reps
	All.Stuff$VSq.mt <- All.Stuff$VSq.mt/n.reps
	
	All.Stuff$V.hat = All.Stuff$V.mt  
	All.Stuff$D.hat = apply(All.Stuff$D.mt,1,mean) 
	
	All.Stuff$X.hat = data$B %*% diag(All.Stuff$D.hat) %*% t(All.Stuff$V.hat)
	All.Stuff$B.hat = t(t(data$X %*% All.Stuff$V.hat)/All.Stuff$D.hat)
	
	All.Stuff$fullV.hat=array(0,c(ncol(data$fullX), data$q))
	All.Stuff$fullV.hat[data$include.x,]=All.Stuff$V.hat
	All.Stuff$fullX.hat=array(0,dim(data$fullX))
	All.Stuff$fullX.hat[,data$include.x]=All.Stuff$X.hat
	
	All.Stuff$parm <- parm
	All.Stuff$init.parm <- init.parm
	
	All.Stuff
	}


fn.trueAnalysis <- function(All.Stuff, true_parm, lower.limit=.025, upper.limit=.975)
{
  est = NULL
  est$tau = mean(All.Stuff$tau.v)
  est$D.v = apply(All.Stuff$D.mt,1,mean)
  est$V.v = as.vector(All.Stuff$V.mt)
  est$X = All.Stuff$X.hat
  est$B = All.Stuff$B.hat
  
  #########
  
  est$tauCI = quantile(All.Stuff$tau.v, prob=c(lower.limit,upper.limit))
  est$D_CI.mt = t(apply(All.Stuff$D.mt,1,quantile, prob=c(lower.limit,upper.limit)))
  est$V_SD.v = sqrt(as.vector(All.Stuff$VSq.mt)-est$V.v^2)
  tmp = array(,c(length(est$V_SD.v),2))
  tmp[,1] = est$V_SD.v*qnorm(lower.limit)
  tmp[,2] = est$V_SD.v*qnorm(upper.limit)
  est$V_CI.mt = est$V.v + tmp
  
  #########
  
  trueV.v = as.vector(true_parm$V[data$include.x,])
    
  #########
  
  est$corD = cor(est$D.v, true_parm$D.v)
  est$corV = cor(est$V.v, trueV.v)
  est$corX = cor(as.vector(est$X), as.vector(data$X))
  est$corB = cor(as.vector(est$B), as.vector(data$B))
  
  est
}
