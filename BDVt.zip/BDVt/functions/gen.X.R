
gen.Data <- function(n, p, small.X, r0sq, input.tau=NULL) {

  data = NULL
  true_parm = NULL
  
  data$n = n
  data$p = p
  
	true_parm$U <- array(rnorm(n=n*p),c(n,p))
	true_parm$centered.U = true_parm$U - rowMeans(true_parm$U)
	true_parm$Delta0 = var(t(abs(true_parm$centered.U)^.5))
	
	# orthogonal columns
	true_parm$B0 = eigen(true_parm$Delta0)$vec
	true_parm$E0 = eigen(true_parm$Delta0)$val
	
	# now clip 
	data$q = min(which(cumsum(true_parm$E0)/sum(true_parm$E0) > .95))
	data$B = true_parm$B0[,1:data$q]
	true_parm$E = true_parm$E0[1:data$q]
	tmp.mat =  t(t(data$B) * sqrt(true_parm$E))
	data$Delta = tmp.mat %*% t(tmp.mat)
	
	true_parm$D.v = rev(sort(abs(rnorm(n=data$q,sd=10))))
	
	true_parm$W = array(rnorm(n=data$p*data$q),c(data$p,data$q))
	# Gram-schmidt process on columns of true_parm$W
	W.qr = qr(true_parm$W)
	# orthogonal columns
	true_parm$V =qr.Q(W.qr)
	
	tmp.mat = t(t(data$B) * sqrt(true_parm$D.v))
	tmp2.mat = t(t(true_parm$V) * sqrt(true_parm$D.v))
	# XStar = BDV^T
  true_parm$XStar = tmp.mat %*% t(tmp2.mat)
  
  if (rankMatrix(true_parm$XStar) != data$q)
    {stop("Rank of matrix XStar is not q!")}
	
  true_parm$tau = input.tau
  
  data$X = true_parm$XStar + array(rnorm(n=data$n*data$p, sd=1/true_parm$tau),c(data$n,data$p))
  
  data = fn.SmallX(data, r0sq, small.X)
  
  data = fn.dataSummary(data, small.X)

	return(list(data=data, true_parm=true_parm))
}
